let container = document.querySelector('#filmes')

container.innerHTML = ''

$.ajax({
    url: 'https://swapi.dev/api/films',
    dataType: 'json',
    success: Response => {
        for(let i = 0; i < Response.count; ++i) {
            let liEl = document.createElement('li')
            liEl.dataset.idEpisodio = `${i+1}`
            
            liEl.innerHTML = `Episode ${i+1}: ${Response.results[i].title}`
            
            container.appendChild(liEl)
        }
    }
})

let $filmes = $('#data')
